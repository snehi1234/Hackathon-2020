"""
Creation Date - 06-08-2020
@author - bsnehith
"""

import os
from flask import Flask, url_for,render_template, redirect,request,abort
from markupsafe import escape
from werkzeug.utils import secure_filename
from Dental_classification import get_pred

app = Flask(__name__)
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
app.config['MAX_CONTENT_LENGTH'] = 10240 * 10240
app.config['UPLOAD_EXTENSIONS'] = ['.jpg', '.png', '.gif','.jpeg']
app.config['UPLOAD_PATH'] = '/Users/bsnehith/Desktop/Hackathon/Dental_Prediction/static'




@app.route('/')
def index():

    return render_template("main.html")

@app.route('/prediction', methods=['POST'])
def func():
    return render_template("prediction.html")

#array = [information according to the classes]


@app.route('/result', methods=['POST'])
def func2():
    uploaded_file = request.files['file']
    filename = secure_filename(uploaded_file.filename)
    print(filename)
    if filename != '':
        file_ext = os.path.splitext(filename)[1]
        if file_ext not in app.config['UPLOAD_EXTENSIONS']:
            abort(400)
        uploaded_file.save(os.path.join(app.config['UPLOAD_PATH'], filename))
        s=get_pred("/Users/bsnehith/Desktop/Hackathon/Dental_Prediction/dataset/training",os.path.join(app.config['UPLOAD_PATH'], filename))
        if s=="canker_sore":
            return render_template("canker_sore.html")
        elif s=="cavity":
            return render_template("cavity.html")
        elif s=="cold_sore":
            return render_template("cold_sore.html")
        elif s=="darkened_tooth":
            return render_template("darkened_tooth.html")
        elif s=="dry_mouth":
            return render_template("dry_mouth.html")
        elif s=="gum_disease":
            return render_template("gum_disease.html")
        else :
            return render_template("normal.html")




if __name__=="__main__" :
    app.run(host="localhost", port=int("1234"))